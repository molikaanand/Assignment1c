#include <stdio.h>

int main(void) {
    int n;
    scanf("%d", &n);

    int middle = (n + 1) / 2;

    for (int row = 1; row <= n; row++) {
        int wings = (row <= middle) ? row : n - row + 1;
        int spaces = 2 * (middle - wings) + 1;

        for (int j = 1; j <= wings; j++) {
            printf("*");
        }
        for (int s = 1; s <= spaces; s++) {
            printf(" ");
        }
        for (int j = 1; j <= wings; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
